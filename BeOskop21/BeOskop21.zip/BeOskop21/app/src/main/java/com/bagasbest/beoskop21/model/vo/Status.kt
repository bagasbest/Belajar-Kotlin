package com.bagasbest.beoskop21.model.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}