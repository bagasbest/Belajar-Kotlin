package com.bagasbest.beoskop21.model.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}